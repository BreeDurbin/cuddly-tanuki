/* 
 * File:   main.c
 * Author: Brian Durbin
 *
 * Created on September 12, 2014, 6:08 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


/* card structure definition */
struct card {
	const char *face; /* define pointer face */
	const char *suit; /* define point suit */
	int value;
}; /*end structure card */

typedef struct card Card; /* new type name for struct card */

/* prototypes */
void fillDeck( Card * const wDeck, const char * wFace[],
	const char * wSuit[], const int cardVals[] );
void shuffle ( Card * const wDeck);


void playhand(Card deck[], int *win);
int gameover();
int scorekeeper(int * playercash, int *win,unsigned int *bet);
int strtolconverter();

int main(){
	int template [] = {2,3,4,5,6,7,8,9,10,10,10,10,11};
        int startingcash = 100;
        int endgame = 0;
        int playercash = 100;
        unsigned int bet = 0;
        int win = 2;
        
        /////////////////////////////////////////////////////////////////////////////////
        Card deck[52]; /* define array of Cards */
        /////////////////////////////////////////////////////////////////////////////////
        /* initialize pointers */
	const char *face[] = { "Ace", "Duece","Three", "Four", "Five",
		"Six", "Seven", "Eight", "Nine", "Ten",
		"Jack", "Queen", "King"};
	const int cardVals[] = {11,2,3,4,5,6,7,8,9,10,10,10,10};
	
	const char *suit[] = {"Hearts", "Diamonds", "Clubs", "Spades"};

	srand( time (NULL ) ); /*randomize */

	fillDeck( deck, face, suit,cardVals ); /*Load the deck with cards */
	shuffle( deck ); /* put Cards in random order */
	
        //////////////////////////////////////////////////////////////////////////////////
        
        printf("You have $%d dollars.\n",playercash);
        printf("A sign at the table says: Minimum bet $10, Maximum bet $500.\n");
        
        while(playercash >= 0){
            
            printf("Play a hand of Blackjack? 1 = Game on!, 2 = Game off!\n");
            while(endgame != 1 && endgame != 2){
                endgame = strtolconverter();
                if(endgame != 1 && endgame != 2){
                    printf("The dealer stares at you quizzically while you try to decide if you feel like losing your money.\n");
                    printf("1 = Game on!, 2 = Game off!\n");
                }
            }
            if (endgame == 2){
                gameover(&playercash, startingcash);
                break;
            }
            printf("Place your bet in dollars.\n");
            while(bet < 10 || bet > 500 || bet > playercash){
                bet = strtolconverter();
                if(bet > playercash){
                    printf("You realize you have less money on you than you thought. Rethink your bet. You have $%d.\n",playercash);
                    bet = strtolconverter();
                }
                if(bet < 10 || bet > 500){
                        printf("The dealer points to the sign at the table.\n");
                        printf("The sign at the table says: Minimum bet $10, Maximum bet $500.\n");
                }
            }
            printf("You bet %d dollars.\n",bet);
            endgame = 0;
            playhand(deck, &win);
            scorekeeper(&playercash, &win, &bet);
            shuffle(deck);
        }
    return 0;  
}

// plays a hand of blackjack
void playhand(Card deck[], int *win){
    int playerhandscore, dealerhandscore;
    int endhand;
    int playerace = 0;
    int dealerace = 0;
    int whileswitch = 1;
    endhand = 0;
    dealerhandscore = 0;
    playerhandscore = 0;
    
    //initialization phase: deals hands and records aces
    dealerhandscore = deck[0].value + deck[1].value;
    if(!strcmp(deck[0].face, "Ace")) dealerace++;
    if(!strcmp(deck[1].face, "Ace")) dealerace++;
    
    playerhandscore = deck[2].value + deck[3].value;
    if(!strcmp(deck[2].face, "Ace")) playerace++;
    if(!strcmp(deck[3].face, "Ace")) playerace++;
    printf("Player got a %s of %s(%d) and %s of %s(%d).\n",deck[2].face,deck[2].suit ,deck[2].value ,deck[3].face, deck[3].suit ,deck[3].value);
    printf("Dealer is showing a %s of %s (%d).\n",deck[1].face, deck[1].suit, deck[1].value);
    printf("Hit or stay? (1 = Hit, 2 = Stay)\n");
    while(endhand != 1 && endhand != 2){
        endhand = strtolconverter();
        if(endhand != 1 && endhand != 2){
            printf("The dealer shoots a confused look your way, trying to figure out what your hand signal meant. 1 = Hit, 2 = Stay");
        }
    }
    printf ("Dealer flips  their first card; a %s of %s(%d).\n", deck[0].face, deck[0].suit, deck[0].value);

    // cycles through cards after initialization
    for(int i = 4; i < 52; i++){
        // player's actions
        if(endhand == 1){
            playerhandscore = playerhandscore + deck[i].value;
            printf("Player got a %s of %s (%d), \nSo Player's score is %d.\n",deck[i].face, deck[i].suit, deck[i].value,playerhandscore);
            if(!strcmp(deck[i].face, "Ace")){
                playerace++;
                printf("Player now has %d ace.\n\n", playerace);
            }
            i++;
            
            if (playerhandscore > 21){
                // turns an ace into a 1 if needed
                if (playerace >= 1){
                    playerhandscore = playerhandscore - 10;
                    printf("Player has an ace.\nSo Player's score becomes %d.\n", playerhandscore);
                    --playerace;
                    }
                if (playerhandscore > 21){
                    printf("Player loses!\n");
                    *win = 0;
                    break;
                }
            }
        }
        // dealer ai
        if((endhand == 2) && (dealerhandscore > playerhandscore)) break;
        if ((dealerhandscore <= 17) || (dealerhandscore <= playerhandscore)){            
            dealerhandscore = dealerhandscore + deck[i].value;
            printf("Dealer draws a %s of %s (%d).\nSo Dealer's score is %d.\n",deck[i].face,deck[1].suit, deck[i].value, dealerhandscore);
            if(!strcmp(deck[i].face, "Ace")){
                dealerace++;
                printf("Dealer now has %d ace.\n\n", dealerace);
            }
            
            if (dealerhandscore > 21){
                // turns an ace into a 1 if needed
                if (dealerace >= 1){
                    dealerhandscore = dealerhandscore - 10;
                    printf("Dealer has an ace.\nSo Dealer's score becomes %d.\n", dealerhandscore);
                    --dealerace;
                    }
                if (dealerhandscore > 21){
                    printf("Dealer loses!\n");
                    *win = 1;
                    break;
                }
            }
        }
        printf("Hit or stay? (1 = Hit, 2 = Stay)\n");
        while(endhand != 1 || endhand != 2){
            endhand = strtolconverter();
            if(endhand != 1 && endhand != 2){
                printf("The dealer shoots a confused look your way, trying to figure out what your hand signal meant. 1 = Hit, 2 = Stay");
            }
            if(endhand = 1)continue;
            if(endhand = 2)break;
        }
    }
    if(*win == 2){
        if (playerhandscore >= dealerhandscore){
            *win = 1;
            printf("Player wins %d to %d.\n\n",playerhandscore,dealerhandscore);
        }
        else {
            *win = 0;
            printf("Player loses %d to %d.\n\n",playerhandscore,dealerhandscore);
        }
    }
}

int scorekeeper (int * playercash, int *win,unsigned int *bet){
    
    // win == 1 means player wins
    if (*win == 1){
        *playercash = *playercash + *bet;
        printf("You won %d dollars.\nYou now have %d dollars.\n",*bet, *playercash);
        *bet = 0;
        *win = 2;
    }
    // win == 0 means player loses hand
    if (*win == 0){
        *playercash = *playercash - *bet;
        printf("You lost %d dollars.\nYou now have %d dollars.\n",*bet, *playercash);
        *bet = 0;
        *win = 2;
    }
}

int gameover(int *playercash){
    int netcash;
    
    if (*playercash > 100){
        netcash = *playercash - 100;
        printf("You won a total of %d dollars\n",netcash);
    }
    if (*playercash == 100){
        printf("You broke even.\n");
    }
    if (*playercash < 100) {
        netcash = 100 - *playercash;
        printf("You lost a total of %d dollars\n",netcash);
    }
}

// converts strings to integers This is a string to long converter I got off the interwebs, then modified for my own purposes cause scanf suxored.
int strtolconverter(){
  char buffer[BUFSIZ];
  char *ch;
  long int temp;

    if (fgets(buffer, sizeof(buffer), stdin) != NULL){
        temp = strtol(buffer, &ch, 10);
    
    // Try to evaluate the output value of that logical statement. :)
        if (!(buffer[0] != '\n' && (*ch == '\n' || *ch == '\0'))){
            printf ("Invalid input entered\n");
        }
    }  
  
    return(temp);
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* Place strings into Card structures */
void fillDeck( Card * const wDeck, const char *wFace[],
	const char * wSuit[], const int cardVals[] )
{
	int i; /* counter */

	/* loop through wDeck */
	for( i = 0; i <= 51; i++){
		wDeck[i].face = wFace[i % 13];
		wDeck[i].value = cardVals[i % 13];
		wDeck[i].suit = wSuit[i / 13];
	}/* end for */
}/* end function fillDeck */

/* Shuffle Cards */
void shuffle (Card * const wDeck){
	int i; /* counter */
	int j; /* variable to hold random value between 0 - 51 */
	Card temp; /* define temporary structure for swapping Cards */

	/* Loop through wDeck randomly swapping Cards */
	for( i = 0; i <= 51; i++){
		j  = rand() % 52;
		temp = wDeck[i];
		wDeck[i] = wDeck[j];
		wDeck[j] = temp;
	} /* end for loop */
} /* end shuffle function */

