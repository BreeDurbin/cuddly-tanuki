/* 
 * File:   main.c
 * Author: Brian Durbin
 *
 * Created on October 10, 2014, 4:47 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <assert.h>
#include <string.h>

/*
 * 
 */

//explicit declaration of functions (this is just telling what types of variables get passed to the fn)
// pointer operators to not dereference within the parens in this case (I think)
// assert (expression, 'error message if condition is false');

int getstr (char ** lineptr, size_t *n, FILE * stream, char terminator, int offset);
void reverseLines(const char ** printOutput, char *lines[*lineCtr]);
void reverseWords(const char ** printOutput, char *lines[*lineCtr]);
ssize_t getline(char **lineptr, size_t *n, FILE *stream);

int main(int argc, char** argv) {
 
    char **lineptr;
    char * lines[1024];
    int lineCtr = 0;
    const char ** printOutput;
    FILE *stream;
    size_t *n;
    
    // repeatedly assigns strings into the pointer of arrays lines[]
    while(!feof(stdin)){	
        ssize_t getline(char **lines, size_t *n, FILE * stream);  // FILE is the pointer of the stream?
    }
    
    //reverse lines
    if(!strcmp(argv[1], "-L")){
        reverseLines(printOutput, &lines[&lineCtr]);
    }
    
    //reverse words
    if(!strcmp(argv[1], "-W")){
        reverseWords(printOutput, &lines[&lineCtr]);
    }
    
    // prints out the reversed words or reversed lines
    while(* printOutput != NULL){
        printf("output: %s", printOutput);
        printOutput++;
    }
    
    return (EXIT_SUCCESS);
}

void reverseWords(const char ** printOutput,char *lines[*lineCtr]){
    while(sscanf(*lines[*lineCtr], "%s", printOutput) != (' ' || '\n'));
    
}

void reverseLines(const char ** printOutput, char *lines[],int *lineCtr){
    while(lines != NULL){
        *printOutput = *lines;
        printOutput++;
    }
}


/* getline.c -- Replacement for GNU C library function getline

Copyright (C) 1993 Free Software Foundation, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

/* Written by Jan Brittenson, bson@gnu.ai.mit.edu.  */



/* Read up to (and including) a TERMINATOR from STREAM into *LINEPTR
   + OFFSET (and null-terminate it). *LINEPTR is a pointer returned from
   malloc (or NULL), pointing to *N characters of space.  It is realloc'd
   as necessary.  Return the number of characters read (not including the
   null terminator), or -1 on error or EOF.  */
// gets a ** line ptr size_t *n is for stringsize file *stream is ? as an arg? , terminator is \0, offset?
//I DO NOT NEED TO CALL THIS FUNCTION DIRECTLY CALL getline() instead!


int getstr (char ** lineptr, size_t *n, FILE * stream, char terminator, int offset)
{
  int nchars_avail;             /* Allocated but unused chars in *LINEPTR.  */
  char *read_pos;               /* Where we're reading into *LINEPTR. */
  int ret;

  if (!lineptr || !n || !stream)
    return -1;

  if (!*lineptr)
    {
      *n = 64;
      *lineptr = (char *) malloc (*n);
      if (!*lineptr)
        return -1;
    }

  nchars_avail = *n - offset;
  read_pos = *lineptr + offset;

  for (;;)
    {
      register int c = getc (stream);

      /* We always want at least one char left in the buffer, since we
         always (unless we get an error while reading the first char)
         NUL-terminate the line buffer.  */

      assert(*n - nchars_avail == read_pos - *lineptr);
      if (nchars_avail < 1)
        {
          if (*n > 64)
            *n *= 2;
          else
            *n += 64;

          nchars_avail = *n + *lineptr - read_pos;
          *lineptr = (char *) realloc (*lineptr, *n);
          if (!*lineptr)
            return -1;
          read_pos = *n - nchars_avail + *lineptr;
          assert(*n - nchars_avail == read_pos - *lineptr);
        }

      if (c == EOF || ferror (stream))
        {
          /* Return partial line, if any.  */
          if (read_pos == *lineptr)
            return -1;
          else
            break;
        }

      *read_pos++ = c;
      nchars_avail--;

      if (c == terminator)
        /* Return the line.  */
        break;
    }

  /* Done - NUL terminate and return the number of chars read.  */
  *read_pos = '\0';

  ret = read_pos - (*lineptr + offset);
  return ret;
}

ssize_t getline(char **lineptr, size_t *n, FILE *stream)
{
  return getstr (lineptr, n, stream, '\n', 0);
}
