
package hw_8_brian_durbin;


public class Hw_7_Brian_Durbin {

    public static void main(String[] args) {
        boolean ignorecase = true;
        TextReader read = new TextReader("C:\\Speech.txt");
        BST tree = new BST();
        String nextword;
        nextword = read.GetWord();  //initial read
        
        // inserts the words into the tree
        while (nextword != null){
            tree.Insert(nextword, ignorecase);
            nextword = read.GetWord();
        }
        
        // display the tree
        //tree.display();
        
        tree.AvgSearch();
        
        System.out.println("\n|Node Count:" + tree.nodecount());
        System.out.println("\n|Tree height: " + tree.height());
        System.out.println("\n|Node Comparisons:" + tree.total);
        System.out.println("\n|Average Comparisons:" + tree.Average());
        
        
    }
    
}