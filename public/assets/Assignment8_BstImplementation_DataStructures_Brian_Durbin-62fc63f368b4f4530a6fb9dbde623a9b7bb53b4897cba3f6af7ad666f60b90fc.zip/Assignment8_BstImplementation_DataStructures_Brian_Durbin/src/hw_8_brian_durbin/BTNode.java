package hw_8_brian_durbin;


public class BTNode {
    String data;
    BTNode left, right;
    int occur = 1; // keeps track of the number of occurances of a string in the tree
    
        BTNode(String val, BTNode L, BTNode R){
            data = val;
            left = L;
            right = R;
        }
}
