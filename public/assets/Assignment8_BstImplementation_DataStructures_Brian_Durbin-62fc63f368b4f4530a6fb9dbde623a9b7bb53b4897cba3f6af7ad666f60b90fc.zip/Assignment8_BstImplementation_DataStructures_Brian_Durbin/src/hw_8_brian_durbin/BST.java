
package hw_8_brian_durbin;

public class BST {
    private BTNode root;
    private int displaycount;
    static int total;
    
    public BST(){
        root = null;
        
    }
    // inserts a new string into the tree
    public void Insert(String value, boolean ignorecase){
        if (ignorecase) 
            value = value.toLowerCase();  

        if (root == null) 
            root = new BTNode(value, null, null);
        
        else InsertR(root, value);
    }
    
    private void InsertR(BTNode n, String value){
        if (value.equals(n.data)) n.occur++;
        if (value.compareTo(n.data)< 0){
            if (n.left == null) n.left = new BTNode(value, null, null);
            else InsertR(n.left, value);
        }
        else if (!value.equals(n.data)){
            if(n.right == null) n.right = new BTNode(value, null, null);
            else InsertR(n.right, value);
        }
        
    }
    
    
    // counts number of nodes in tree
    public int nodecount(){
        return nodecountR(root);
    }
    
    private int nodecountR(BTNode n){
        int result = 0; // if n is nul stays 0
        if(n != null)
            result = 1 + nodecountR(n.left) + nodecountR(n.right);
        return result;
    }
    
    // counts number of words in tree
    public int wordcount(){
        return wordcountR(root);
    }
    
    private int wordcountR(BTNode n){
        int result = 0; // if n is nul stays 0
        if(n != null)
            result = n.occur + wordcountR(n.left) + wordcountR(n.right);
        return result;
    }
    // displays the tree
    public void display(){
        displaycount = 0;
        displaycount++;
        if (root!=null) 
            System.out.printf( "|%-10.10s" + "%3d |", root.data, root.occur);
        if(root.left != null)
            displayR(root.left); 
        if(root.right != null)
            displayR(root.right); 
        System.out.printf( "Wordcount = %-10d", wordcount()); //print the wordcount
    }
    // recursively displays nodes in a tree
    private void displayR(BTNode n){
        System.out.printf( "%-10.10s" + "%3d |",n.data, n.occur);
        displaycount++;
        if (displaycount%4==0)
            System.out.print("\n|");
        if(n.left != null)
            displayR(n.left);    
        if(n.right != null)
            displayR(n.right);
    }
    
    public int SearchCount(String val){
        int result = 1; //Default, it took 1 comparison, null check
        if (root != null) {
            if (root.data.equals(val))
                result = 2; //it took 2 compares, null check and = check,
            else
                if (root.data.compareTo(val)<0) //the third compare
                    return 3 + SearchCountR(root.left, val);
            else
                return 3 + SearchCountR(root.right, val);
        }
        return result;
    }
    
    private int SearchCountR(BTNode n, String val) {
        int result = 1; //Default, it took 1 comparison, null check
        if (n != null) {
            if (n.data.equals(val))
            result = 2; //it took 2 compares, null check and = check,
            else
                if (n.data.compareTo(val)<0) //the third compare
                    return 3 + SearchCountR(n.left, val);
            else
                return 3 + SearchCountR(n.right, val);
        }
        return result;
    }
    
    public void AvgSearch(){// travers the tree in order recursively
        displaycount = 0;
        System.out.print("|");
        AvgSearchR(root);
    }
    
    private void AvgSearchR(BTNode n){// recursive function adding up the number
        displaycount++;               // of comparisons and printing contents
        if (n!=null) 
            System.out.printf( "|%-10.10s" + "%3d |", n.data, n.occur);
        if (displaycount%4==0)
            System.out.print("\n|");
        total = total + SearchCount(n.data);
        if(n.left != null) AvgSearchR(n.left);
        if(n.right != null) AvgSearchR(n.right);
    }
    
    // averages the number of comparisons to find a sting
    
    float Average(){
        float average;
        average = total/nodecount();
        return average;
    }
    
    // prints the height of the tree
    int height(){
        return heightR(root, -1);
    }
    
    private int heightR(BTNode n, int level){
        int result = level; // if null, no change
        if(n!=null){
            result = Math.max(
                    heightR(n.left, level+1),
                    heightR(n.left, level+1)
            );       
        }
        return result;
    }
    
    

}