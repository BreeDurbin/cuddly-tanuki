/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_brian_durbin;
import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class HW4_Brian_Durbin {

    
    public static void reverseQueue(Aqueue myqueue){
        Astack s = new Astack();
        s.Stack(myqueue.size());
        while(!myqueue.isEmpty()) s.push(myqueue.remove());
        while(!s.isEmpty()) myqueue.insert(s.pop());
    }
    
    
    
    public static void main(String[] args) {
        Astack mystack = new Astack();
        Aqueue myqueue = new Aqueue();
        mystack.Stack(7);
        myqueue.Queue(5);
        Scanner input = new Scanner(System.in);
        System.out.print("Enter 7 strings with values of 4 to 10 characters.\n");
        while(mystack.size() < 7){
            mystack.push(input.next());
        }
        System.out.print("Enter 5 strings with values of 4 to 10 characters.\n");
        while(myqueue.size() < 5){
            myqueue.insert(input.next());
        }
        reverseQueue(myqueue);
        reverseStack(mystack);
        mystack.display();
        myqueue.display();
        
    }
    
}
