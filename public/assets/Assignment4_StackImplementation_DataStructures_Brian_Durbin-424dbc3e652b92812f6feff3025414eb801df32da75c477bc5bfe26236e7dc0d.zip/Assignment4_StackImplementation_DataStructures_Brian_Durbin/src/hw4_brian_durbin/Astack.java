/*
 Modified Stack package from Ch 11 Data structures and algorithms by Al Brouillette
Modified to handle strings as opposed to ints
 */
package hw4_brian_durbin;

/**
 *
 * Brian Durbin
 */
public class Astack {
   private String [] storage;
   private int top;
   
   public void Stack(int n){
       storage = new String[n];
       top = -1;
   }
   
   public void push(String value){
       if(top < (storage.length-1)){
           top++;
           storage[top] = value;
       }
   }
   
   public String pop(){
       String result = "Empty";
       if(!isEmpty()){
           result = storage[top];
           top--;
       }
       return result;
   }
   
   public String top(){
       String result = "Empty";
       if(!isEmpty()){
           result = storage[top];
       }
       return result;
   }
   
   public int size(){
       return (top+1);
   }
   
   public boolean isEmpty(){
       return top < 0;
   }
   
   public void display(){
        int i;
        if(!isEmpty()){
            i=0;
            int j, k;
            System.out.print("     ");
            for (j = 0; j < size(); j++){
                for(k = 0 ; k < storage[k].length(); k++){
                    System.out.print("-");
                }
                System.out.print("-");
            }
            System.out.print("-\n");
            
            System.out.print("TOP |");
            
            while(i<top){
                System.out.print(storage[i]+"|");
                i++;
            }
            
            System.out.print(storage[i]+"|");
            
            System.out.print("\n");
            
            System.out.print("     ");
            for (j = 0; j < size(); j++){
                for(k = 0 ; k < storage[k].length(); k++){
                    System.out.print("-");
                }
                System.out.print("-");
            }
            System.out.print("-\n");
            
        }
        else System.out.print("Empty");
        System.out.print("\n");
    }
   
   public void reverseStack(Astack mystack){
        Aqueue q = new Aqueue();
        q.Queue(mystack.size());
        while(!mystack.isEmpty()) q.insert(mystack.pop());
        while(!q.isEmpty()) mystack.push(q.remove());
    }
}
