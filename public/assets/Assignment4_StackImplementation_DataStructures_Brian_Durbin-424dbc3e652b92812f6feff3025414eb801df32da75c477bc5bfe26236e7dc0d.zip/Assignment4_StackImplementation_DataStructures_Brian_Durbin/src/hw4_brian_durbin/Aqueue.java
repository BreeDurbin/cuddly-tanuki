/*
 * Modified Queue package from Ch 12 Data structures and algorithms by Al Brouillette
Modified to handle strings as opposed to ints
 */
package hw4_brian_durbin;

/**
 *
 * @author Administrator
 */
public class Aqueue {
    private int capacity;
    private String[] storage;
    private int front, rear;
    private boolean empty;
    
    public void Queue(int size){
        capacity = size;
        storage = new String[capacity];
        front = 0;
        rear = -1;
        empty = true;
    }
    
    public void insert(String value){
        if (size()<capacity){
            rear++;
            if (rear == capacity){
                rear = 0;    
            }
            storage[rear] = value;
            empty = false;
        }
    }
        
    public String remove(){
        String result =  storage[front];
        front++;
        if(front==capacity){
            front = 0;
        }
        empty = ((front == rear + 1) || ((front==0)&&(rear==(capacity-1))));
    return result;
    }
    
    public String front(){
        return storage[front];
    }
    
    public int size(){
        int result;
        int gap;
        if(empty) result = 0;
        else{
            if(rear>=front) result = rear-front+1;
            else{
                gap = front - rear -1;
                result = capacity - gap;
            }
        }
        return result;
    }
    
    public boolean isEmpty(){
        return size() == 0;
    }
    
    public void display(){
        int i;
        int j, k;
        System.out.print("     ");
        for (j = 0; j < size(); j++){
            for(k = 0 ; k < storage[k].length(); k++){
                System.out.print("-");
            }
            System.out.print("-");
        }
        System.out.print("\n");
            
        if(!isEmpty()){
            i=front;
            System.out.print("TOP |");
            while(i!=rear){
                System.out.print(storage[i]+"|");
                i++;
                if (i==capacity) i=0;
            }
            System.out.print(storage[rear]+"|");
        }
        else System.out.print("Empty");
        
        System.out.print("\n     ");
        for (j = 0; j < size(); j++){
            for(k = 0 ; k < storage[k].length(); k++){
                System.out.print("-");
            }
            System.out.print("-");
        }
        System.out.print("\n");
    }
    
    public void reverseQueue(Aqueue myqueue){
            Astack s = new Astack();
            s.Stack(myqueue.size());
            while(!myqueue.isEmpty()) s.push(myqueue.remove());
            while(!s.isEmpty()) myqueue.insert(s.pop());
    }
}
