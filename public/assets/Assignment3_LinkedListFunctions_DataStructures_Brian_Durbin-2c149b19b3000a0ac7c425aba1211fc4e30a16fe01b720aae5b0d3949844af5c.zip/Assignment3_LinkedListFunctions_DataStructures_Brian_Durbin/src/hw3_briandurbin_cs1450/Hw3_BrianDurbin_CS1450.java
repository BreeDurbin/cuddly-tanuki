/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw3_briandurbin_cs1450;

/**
 *
 * @author Brian Durbin
 */
public class Hw3_BrianDurbin_CS1450 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    OrderedStringList myList = new OrderedStringList(7);
    
    System.out.println("Adding Hello Brian Durbin Space");
    myList.insert("Adding");
    myList.insert("Hello");
    myList.insert("Brian");
    myList.insert("Durbin");
    myList.insert("Space");
    myList.display();
    
    System.out.println("myList's size:"+myList.size());
    
    System.out.println("Mylist's find function"+myList.find("Hello"));
    myList.display();
    
    System.out.println("Mylist deleting Hello");
    myList.delete("Hello");
    myList.display();
    
    
    }
    
}
