/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw3_briandurbin_cs1450;

/**
 *
 * @author Administrator
 */
public class OrderedStringList{
    private int length;
    private int numUsed;
    private String[] storage;

    public OrderedStringList(int capacity){
        length = capacity;
        storage = new String[length];
        numUsed = 0;   
        }
    
    public boolean insert(String s){
        boolean result = false;
        result = addOrdered(s);
        return result;
    }
    
    public boolean insertList(OrderedStringList newList){
        boolean result = false;
        int newlistsize = newList.size();
        int index = 0;
        if(newlistsize < length){
            while(index < (newlistsize-1)){
                newList.insert(newList.storage[index]);
                index++;
                if (index == (newlistsize-1)) result = true;
            }
        }
        return result;
    }
    
    private boolean addOrdered(String s){
        boolean result = false;
        int index = 0;
        if(numUsed < length){
            while((index < numUsed)&&(storage[index].compareTo(s) < 0)){
                index++;
            }
        moveItemsDown(index);
        storage[index] = s;
        numUsed++;
        result = true;
        }
    return result;    
    }
    
    private int findIndex(String s){
        int result = -1;
        int index = 0;
        boolean found = false;
        while((index < numUsed) && (!found)){
            found = (s.equals(storage[index]));
            if (!found) index++;
        }
        if(found) result = index;
        return result;
    }
    
    public boolean find(String s){
        return(findIndex(s) >= 0);
    }
    
    public boolean delete(String s){
        boolean result = false;
        int location;
        location = findIndex(s);
        if(location >= 0){
            moveItemsUp(location);
            numUsed--;
            result = true;
        }
        return result;
    }
    
    public int size(){
            return numUsed;
    }
    
    public int maxSize(){
        return length;
    }
    
    public void display(){
        int index;
        System.out.println("List Contents:");
        for (index = 0; index < numUsed; index++){
            System.out.println(index+"  "+storage[index]);
            
        }
        System.out.println("--------------");
        System.out.println();
    }
    
    private void moveItemsDown(int start){
        int index;
        for (index = numUsed-1; index >= start; index--){
            storage[index+1] = storage[index];
        }
    }
    
    private void moveItemsUp(int start){
        int index;
        for(index = start; index < numUsed - 1; index++){
           storage[index] = storage[index+1];
        }
    }
}

