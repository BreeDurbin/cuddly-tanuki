/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw3_briandurbin_cs1450;

/**
 *
 * @author Administrator
 */
public class OrderedStringListClass {
    
}
