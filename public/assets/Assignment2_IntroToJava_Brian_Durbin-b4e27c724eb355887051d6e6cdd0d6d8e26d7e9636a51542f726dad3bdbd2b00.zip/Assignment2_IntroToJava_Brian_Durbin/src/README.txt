Array functions for java

summation(array)
average(array)
minVal(array)
maxVal(array)

By Brian Durbin for Comp Sci 161 Intro to Java programming.
