/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */

import java.util.Scanner;
        
public class Hw2_main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int output = 0;
        double output2 = 0;
        arrayUtils instance = new arrayUtils();
        try (Scanner input = new Scanner(System.in)) {
            for(int count = 0; count < arrayUtils.array.length ; count++){
                arrayUtils.array[count] = input.nextInt();
            }
        }    
        // print the contents of the array
        for(int count = 0; count < arrayUtils.array.length ; count++){
            System.out.println(arrayUtils.array[count]);
        }
        
        output = instance.maxVal();
        System.out.println(output);
        output = instance.minVal();
        System.out.println(output);
        output = instance.summation();
        System.out.println(output);
        output2 = instance.average();
        System.out.println(output2);
    }
    
}

