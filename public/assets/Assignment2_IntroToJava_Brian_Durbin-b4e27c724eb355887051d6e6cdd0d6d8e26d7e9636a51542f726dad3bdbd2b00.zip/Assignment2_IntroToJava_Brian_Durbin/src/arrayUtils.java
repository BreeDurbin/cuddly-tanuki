/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Brian Durbin with modified funtions from Designing data structures in java: a software engineering approach by Albert Brouillette
 */
public class arrayUtils {
    public static int[] array = new int[250];
    
    public int maxVal(){
        int index;
        int max = array[0];
        for (index = 1; index < array.length; index++){
            if (array[index] > max)
                max = array[index];
        }
        if (array.length < 1) max = -1;
        return max;
    }
    
    public int minVal(){
        int index;
        int min = array[0];
        for (index = 1; index < array.length; index++){
            if (array[index] < min)
                min = array[index];
        }
        if (array.length < 1) min = -1;
        return min;
    }
    
    public int summation(){
        int index;
        int sum = 0;
        for(index=0; index <array.length; index++){
            sum = sum + array[index];
        }
        if (array.length < 1) sum = -1;
        return sum;
    }
    
    public double average(){
        double avg = summation()/ array.length;
        if (avg < 1) avg = -1.0;
        return avg;
    }
    
    

}


