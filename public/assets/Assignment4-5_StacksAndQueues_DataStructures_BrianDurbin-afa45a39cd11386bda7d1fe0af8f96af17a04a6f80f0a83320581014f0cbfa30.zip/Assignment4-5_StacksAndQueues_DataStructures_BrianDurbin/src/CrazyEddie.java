public class CrazyEddie {
    Car tempcar = new Car();
    private int carsinqueue = 0;
    private int carsinstack = 0;
    private int carsremoved = 1;
    private int plateNumber = 10000;
    private final char actionCode = 'E';
    
    // creates a new car with a plate based on a given parameter t
    Car MakeANewCarAndPlate(int t){

        String plateString = Integer.toString(plateNumber);
        tempcar.setter(plateString, actionCode);
        plateNumber += 10;
        return tempcar;
    }
    
    // handles arrivals to crazy eddies valet service
    void HandleArrival(Car newCar, Lqueue carqueue , Lstack carstack){

        // if queue is not full put a car in the queue
        if (carsinqueue < 7){
            System.out.println("Car #" + tempcar.getterplates() + " added to alley.\n");
            carqueue.insert(newCar);
            carsinqueue++;

        }
        //if queue is full put into stack
        if ((carsinqueue == 7) && (carsinstack < 4)){
            System.out.println("Car #" + tempcar.getterplates() + " added to driveway.\n");
            carstack.push(newCar);
            carsinstack++;
        }
        //if queue and stack are full turn away
        if ((carsinqueue == 7) && (carsinstack == 4)){
            System.out.println("Sorry parking is full, Car #" + tempcar.getterplates() + " is turned away.\n");
            carsremoved++;
            System.out.println("new number of cars to be removed each removal:" + carsremoved);
        }
    }
    
    // handles departures from crazy eddies valet service
    void HandleRemovals(Lqueue carqueue){
        int i;
        System.out.print("REMOVED ");
        for(i = 1; i <= carsremoved; i++){
            System.out.print("#" + carqueue.front.next.data.getterplates() + ",");
            carqueue.remove();
        }
        System.out.println("\n");
    }
    
    // moves as many cars as possible from driveway to alley
    void TryToEmptyDriveway(Lqueue carqueue , Lstack carstack){
        //move cars from driveway to alley
        boolean carsmoved = false;
        while((carsinqueue < 7) && (carsinstack >= 1)){
            //if there are cars in driveway and alley is not full then move one to alley
            if ((carsinqueue < 7) && (carsinstack >= 1)){
                carqueue.insert(carstack.pop());
                carsinstack--;
                carsinqueue++;
                System.out.println("Moving car #" + tempcar.getterplates() + "from the driveway to the alley.");
                carsmoved = true;
            }
            // if cars were moved display driveway and alley contents
            if (carsmoved){
                System.out.println("After driveway moves:");
                carqueue.display();
                carstack.display();
                carsmoved = true;
            }
        }
    }
    
    // displays contents of the alley and driveway at the end
    void DisplayFinalAlleyNDriveway(Lqueue carqueue, Lstack carstack){
        System.out.print("Final Coniguration\n");
        carqueue.display();
        carstack.display();
    } 
}
