
public class Lqueue {
    public Node front, rear;
    
    public Lqueue(){
        front = null;
        rear = null;
    }
    
    public void insert(Car inputcar){
        if (front==null){
            front = new Node(inputcar, null);
            front.data.newCar();
            rear = front;
        }
        
        else{
            rear.next = new Node(inputcar, null);
            rear.next.data.newCar();
            rear = rear.next;
        }
    }
    
    public Car remove(){
        Car temp=front.data;
        front = front.next;
        return temp;
    }
    
    public boolean isEmpty(){
        return(front==null);
    }
    
        
    public int size(){
        int count = 0;
        Node current = front;
        while(current != null){
            count++;
            current = current.next;
        }
        return count;
    }
    
    public void display(){
        int j,k;
        Node current = front;
        System.out.print("       ");
        for (j = 0; j < size(); j++){
            for(k = 0 ; k < current.data.getterplates().length(); k++){
                System.out.print("-");
            }
            System.out.print("-------");
        }
        System.out.print("\nFront ");
        while(current!=null){
            System.out.print("| " + current.data.getterplates() + " | " + current.data.getteraction() + " ");
            current = current.next;
        }
        System.out.print("|\n       ");
        current = front;
        for (j = 0; j < size(); j++){
            for(k = 0 ; k < current.data.getterplates().length(); k++){
                System.out.print("-");
            }
            System.out.print("-------");
        }
        System.out.print("\n");
    }
    
    public void reverseQueue(Lqueue myqueue){
        Lstack s = new Lstack();
        while(!myqueue.isEmpty()){
            s.push(myqueue.remove());
        }
        while(!s.isEmpty()){
            myqueue.insert(s.pop());
        }
    }
}
