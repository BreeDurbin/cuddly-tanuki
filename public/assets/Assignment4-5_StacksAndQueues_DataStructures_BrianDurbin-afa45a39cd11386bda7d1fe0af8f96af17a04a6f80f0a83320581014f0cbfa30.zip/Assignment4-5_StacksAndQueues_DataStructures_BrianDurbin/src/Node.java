
public class Node {
    Car data;
    Node next;
    
    public Node(Car inputcar, Node nxt){
        data = inputcar;
        next = nxt;
    }
    
    
}
