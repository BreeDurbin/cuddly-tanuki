
public class Lstack {
    
    public Node top;
    private int numelements;
    
    public Lstack(){
        top = null;
        numelements = 0;
    }
    
    public void push(Car inputcar){
        top = new Node(inputcar, top);
        top.data.newCar();
        numelements++;
    }
    
    public Car pop(){
        Car temp = top.data.getter();
        top = top.next;
        numelements--;
        return temp;
    }
    
    public int size(){
        return numelements;
    }
    
    public boolean isEmpty(){
        return (top==null);
    }
    
    public void display(){
        int j,k;
        Node current = top;
        System.out.print("    ");
        for (j = 0; j < size(); j++){
            for(k = 0 ; k < current.data.getterplates().length(); k++){
                System.out.print("-");
            }
            System.out.print("-------");
        }
        System.out.print("\nTOP");
        while (current!=null){
            System.out.print("| " + current.data.getterplates() + " | " + current.data.getteraction() + " ");
            current = current.next;
        }
        System.out.print("|\n    ");
        current = top;
        for (j = 0; j < size(); j++){
            for(k = 0 ; k < current.data.getterplates().length(); k++){
                System.out.print("-");
            }
            System.out.print("-------");
        }
        System.out.print("\n");
    }
    
    public void reverseStack(Lstack mystack){
        Lqueue q = new Lqueue();
        while(!mystack.isEmpty()){
            q.insert(mystack.pop());
        }
        while(!q.isEmpty()){
            mystack.push(q.remove());
        }
    }
    
}
