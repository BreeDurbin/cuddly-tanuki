

public class Hw5_Brian_Durbin {

    public static void main(String[] args) {
        Lstack mystack = new Lstack();
        Lqueue myqueue = new Lqueue();
        CrazyEddie parknsave = new CrazyEddie();
        int t;
        
        for (t=1; t<70; t++){
            if (t % 2 == 1){ //time is odd
            Car mycar = new Car();
            mycar.newCar();
            mycar = parknsave.MakeANewCarAndPlate(t);
            parknsave.HandleArrival(mycar, myqueue, mystack);
            }
            if (t % 5 == 0) parknsave.HandleRemovals(myqueue);
            parknsave.TryToEmptyDriveway(myqueue, mystack);
        }
        parknsave.DisplayFinalAlleyNDriveway(myqueue, mystack);        
    }
}

// old hw5 code

//import java.util.Scanner;

/*Scanner input = new Scanner(System.in);
        
        System.out.print("Enter 7 strings with values of 1 to 6 characters.\n");
        while(mystack.size() < 7){
            Car inputcar = new Car();
            inputcar.newCar();
            mystack.push(inputcar);
            inputcar.setter(input.next(), 'X');
        }
        System.out.println("Original Lstack");
        mystack.display();
        mystack.reverseStack(mystack);
        System.out.println("Reversed Lstack:");
        mystack.display();
        
        System.out.print("Enter 5 strings with values of 1 to 6 characters.\n");
        while(myqueue.size() < 5){
            Car inputcar = new Car();
            inputcar.newCar();
            myqueue.insert(inputcar);
            inputcar.setter(input.next(), 'Y');
        }
        System.out.println("Original Lqueue");
        myqueue.display();
        myqueue.reverseQueue(myqueue);
        System.out.println("Reversed Lqueue:");
        myqueue.display();
        */