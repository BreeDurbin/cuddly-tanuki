
public class Car {
    private String plates;
    private char action;
    
    public void newCar(){
        plates = "Empty";
        action = 'E';
    }
    
    // sets plates and action
    public void setter(String storage,char code){
        if ((storage.length()>7)||(storage.length()==0)){
            System.out.print("Invalid input size\n");
        }
        else{
            
            plates = storage;
            action = code;
        }
    }
    
    public String getterplates(){
        if (plates != null){
            String temp = plates;
            return temp;
        }
        
        else{
            plates = "Empty";
            String temp = plates;
            return temp;
        }
    }
    
    public char getteraction(){
        char temp;
        temp = action;
        return temp;
    }
    
    public Car getter(){
        Car temp = new Car();
        temp.newCar();
        temp.setter(plates, action);
        return temp;
    }
}
