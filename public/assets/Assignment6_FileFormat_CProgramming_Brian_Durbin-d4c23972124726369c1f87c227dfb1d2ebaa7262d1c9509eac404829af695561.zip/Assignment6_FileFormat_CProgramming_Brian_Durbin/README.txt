Creates my own file format.

Write and prints out the format

/* 
 * File:   main.c
 * Author: Brian Durbin
 *
 * Created on December 16, 2014, 6:29 AM
 */



/* file structure 
char[6] 	CS2060 (no null)
uint32_t 	index to size/key pair for cypher message

uint32_t	size of name message (ms1)
char []		ms1 string size above

uint32_t	size of plain text message (ms2)
char []		ms2 string size above

uint32_t	size of encrypted text message (ms3)
char []		ms3 string size above

-->location of index
uint32_t	size of name key (sk)
char []		key string size above

*/
