/* 
 * File:   main.c
 * Author: Brian Durbin
 *
 * Created on December 16, 2014, 6:29 AM
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>


/* file structure 
char[6] 	CS2060 (no null)
uint32_t 	index to size/key pair for cypher message

uint32_t	size of name message (ms1)
char []		ms1 string size above

uint32_t	size of plain text message (ms2)
char []		ms2 string size above

uint32_t	size of encrypted text message (ms3)
char []		ms3 string size above

-->location of index
uint32_t	size of name key (sk)
char []		key string size above

*/

void encrypt(char * input, char * key, int size);

int main(int argc, char ** argv){
	FILE * fh;
	
	uint32_t fileIdx,sname, sm1,sm2,sk,scm;
	
        char header[6] = "cs2060";
        char name[] = "Brian Durbin";
        char m1[] = "I liked the difficulty of the class. I didn't dislike any part of the class.";
        char m2[] = "With luck my grade will be an A. We shall see. It will depend if I can get tic tac toe done before tomorrow. I have procrastinated too much.";
        char key[] = "01011001";
        
	
	if(argc > 2){
		return 1;
	}else if (argc == 2){
		fh = fopen(argv[1],"wb");
	}else{
		fh = fopen("outfile.dat","wb");
	}
	
        // fill my variables and pointers
        sname = strlen(name);
        sm1 = strlen(m1);
        sm2 = strlen(m2);
        sk =  strlen(key);
        
        
        //write header
	fwrite(header,6,1,fh);
        
        // write name and namesize
        fseek(fh, 6 + sizeof(uint32_t), SEEK_SET);
        fwrite(&sname,sizeof(uint32_t),1,fh);
        fwrite(name,sname,1,fh);
	
        //write m1
	fwrite(&sm1,sizeof(uint32_t),1,fh);
	fwrite(m1,sm1,1,fh);

        //encrypt and write m2
        encrypt(m2, key, sm2);
	fwrite(&sm2,sizeof(uint32_t),1,fh);
	fwrite(m2,sm2,1,fh);
	
        //assigns the position to fileIdx, writes keysize and key
        fileIdx = ftell(fh);
        fseek(fh, 6, SEEK_SET);
        fwrite(&fileIdx,sizeof(uint32_t),1,fh);
        fseek(fh, fileIdx, SEEK_SET);
	fwrite(&sk,sizeof(uint32_t),1,fh);
	fwrite(key,sk,1,fh);
	
        
	printf("%s\n",header);
	printf("File Index is %d\n",(int)fileIdx);
        
	printf("%s\n",m1);
	printf("%s\n",m2);
	printf("%s\n",key);
        
        
        fclose(fh);
        return(0);


}

void encrypt(char * input, char * key, int size){
    
    int i = 0;
    for ( i; i < size; i++){
        input[i] = input[i] ^ key[i%strlen(key)];
    }
}
